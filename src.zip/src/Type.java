/**
 * Created by sina on 12/23/14.
 */
public class Type {
    String name;
    String parent;
}
