/**
 * Created by sina on 12/27/14.
 */
public class IntType extends Type {
    public IntType() {
        super("Int");
        setInheritable(false);
    }
}
