/**
 * Created by sina on 12/27/14.
 */
public class BoolType extends Type {
    public BoolType() {
        super("Bool");
        setInheritable(false);
    }
}
