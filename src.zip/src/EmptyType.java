/**
 * Created by sina on 12/29/14.
 */
public class EmptyType extends Type {
    public EmptyType() {
        super("empty");
        setEmpty(true);
    }
}
