/**
 * Created by sina on 12/29/14.
 */
public class Pass2Error extends Throwable {
}
